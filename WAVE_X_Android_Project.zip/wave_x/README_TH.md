# WAVE X — Android starter project

โปรเจกต์ Flutter สำหรับแอปคู่หูและสนามฝึกจำลอง WAVE X

## สิ่งที่มี
- เลือก Free Fire หรือ Free Fire MAX เป็นโปรไฟล์เกม
- กรอก UID ด้วยตนเอง (เก็บในหน่วยความจำระหว่างเปิดแอปเท่านั้น)
- เมนูควบคุม ESP / Hitbox / HP สำหรับเป้าหมายจำลองในแอป
- สนามฝึกยิงจำลอง ลด HP และรีเซ็ตเป้าหมาย
- ธีมดำ–น้ำเงินนีออน

## ข้อจำกัด
แอปนี้ไม่ได้เชื่อมต่อบัญชีหรือเซิร์ฟเวอร์ Garena/Free Fire และไม่อ่านข้อมูลจากเกมจริง
ESP, Hitbox และ HP ใช้กับเป้าหมายจำลองในแอปเท่านั้น
ปุ่ม CONTROL เป็นเมนูภายในแอป ไม่ใช่หน้าต่างลอยทับเกม

## วิธีสร้าง APK
ต้องติดตั้ง Flutter SDK, Android Studio และ Android SDK บนคอมพิวเตอร์ก่อน

1. เปิด Terminal ในโฟลเดอร์โปรเจกต์
2. รัน `flutter doctor` และแก้ปัญหาที่รายงาน
3. รัน `flutter pub get`
4. รัน `flutter build apk --release`
5. ไฟล์ APK จะอยู่ที่ `build/app/outputs/flutter-apk/app-release.apk`

## ทดสอบบนมือถือ
เปิด USB debugging แล้วเชื่อมต่อ Android จากนั้นรัน `flutter devices` และ `flutter run`
หรือคัดลอก APK ที่ build เสร็จไปติดตั้งบนมือถือ
