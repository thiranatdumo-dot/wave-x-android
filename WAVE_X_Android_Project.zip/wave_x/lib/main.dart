import 'package:flutter/material.dart';

void main() => runApp(const WaveXApp());

const neonBlue = Color(0xFF00BFFF);
const darkBg = Color(0xFF070B14);
const panel = Color(0xFF111B2B);

class WaveXApp extends StatelessWidget {
  const WaveXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WAVE X',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: darkBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: neonBlue,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const WaveHome(),
    );
  }
}

class WaveHome extends StatefulWidget {
  const WaveHome({super.key});

  @override
  State<WaveHome> createState() => _WaveHomeState();
}

class _WaveHomeState extends State<WaveHome> {
  final uidController = TextEditingController();
  String game = 'Free Fire';
  String savedUid = '';
  bool esp = true;
  bool hitbox = true;
  bool hpDisplay = true;
  int health = 100;
  double sensitivity = 50;

  @override
  void dispose() {
    uidController.dispose();
    super.dispose();
  }

  void saveProfile() {
    final value = uidController.text.trim();
    if (value.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a player UID.')),
      );
      return;
    }
    setState(() => savedUid = value);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('UID saved in this session only. No game connection made.'),
      ),
    );
  }

  void showControls() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: panel,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, updateSheet) => Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('WAVE X CONTROL',
                  style: TextStyle(color: neonBlue, fontSize: 19,
                      fontWeight: FontWeight.bold, letterSpacing: 2)),
              SwitchListTile(
                title: const Text('ESP DISPLAY'),
                subtitle: const Text('Training target label only'),
                value: esp,
                activeColor: neonBlue,
                onChanged: (v) {
                  setState(() => esp = v);
                  updateSheet(() {});
                },
              ),
              SwitchListTile(
                title: const Text('HITBOX'),
                subtitle: const Text('Practice target outline only'),
                value: hitbox,
                activeColor: neonBlue,
                onChanged: (v) {
                  setState(() => hitbox = v);
                  updateSheet(() {});
                },
              ),
              SwitchListTile(
                title: const Text('HP DISPLAY'),
                subtitle: const Text('Practice target health bar'),
                value: hpDisplay,
                activeColor: neonBlue,
                onChanged: (v) {
                  setState(() => hpDisplay = v);
                  updateSheet(() {});
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget panelCard(Widget child) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: panel,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: neonBlue.withValues(alpha: .45)),
          boxShadow: [
            BoxShadow(
              color: neonBlue.withValues(alpha: .08),
              blurRadius: 18,
            ),
          ],
        ),
        child: child,
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: panel,
        centerTitle: true,
        title: const Text('WAVE X',
            style: TextStyle(color: neonBlue, fontWeight: FontWeight.w900,
                letterSpacing: 4)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: showControls,
        backgroundColor: neonBlue,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.tune),
        label: const Text('CONTROL'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('GAMING COMPANION',
              style: TextStyle(color: neonBlue, letterSpacing: 2)),
          const SizedBox(height: 16),
          panelCard(Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('SELECT GAME',
                  style: TextStyle(color: neonBlue,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: game,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.sports_esports),
                ),
                items: const [
                  DropdownMenuItem(value: 'Free Fire', child: Text('Free Fire')),
                  DropdownMenuItem(
                      value: 'Free Fire MAX', child: Text('Free Fire MAX')),
                ],
                onChanged: (v) => setState(() => game = v ?? game),
              ),
              const SizedBox(height: 16),
              const Text('PLAYER UID',
                  style: TextStyle(color: neonBlue,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextField(
                controller: uidController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: 'Enter UID manually',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: saveProfile,
                  child: const Text('SAVE PLAYER PROFILE'),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                savedUid.isEmpty
                    ? 'No UID saved'
                    : 'Saved locally • $game • UID: $savedUid',
                style: TextStyle(
                    color: savedUid.isEmpty
                        ? Colors.white54
                        : Colors.greenAccent),
              ),
              const SizedBox(height: 6),
              const Text(
                'UID is stored only in this running session. This app does not '
                'authenticate with or connect to Garena/Free Fire.',
                style: TextStyle(color: Colors.white54, fontSize: 11),
              ),
            ],
          )),
          const SizedBox(height: 18),
          const Text('TRAINING ARENA',
              style: TextStyle(color: neonBlue, fontWeight: FontWeight.bold,
                  letterSpacing: 2)),
          const SizedBox(height: 10),
          panelCard(Column(
            children: [
              const Text('SIMULATED TARGET',
                  style: TextStyle(color: neonBlue, letterSpacing: 1)),
              const SizedBox(height: 18),
              SizedBox(
                height: 190,
                child: Center(
                  child: Stack(
                    clipBehavior: Clip.none,
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 118,
                        height: 158,
                        decoration: BoxDecoration(
                          border: hitbox
                              ? Border.all(color: neonBlue, width: 2)
                              : null,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Column(
                          children: [
                            SizedBox(height: 8),
                            CircleAvatar(
                              radius: 21,
                              backgroundColor: Color(0xFF52677B),
                              child: Icon(Icons.person, color: Colors.white),
                            ),
                            Expanded(
                              child: Icon(Icons.accessibility_new,
                                  size: 92, color: Colors.white70),
                            ),
                          ],
                        ),
                      ),
                      if (esp)
                        const Positioned(
                          top: -8,
                          right: -48,
                          child: Text('TARGET',
                              style: TextStyle(color: neonBlue, fontSize: 11)),
                        ),
                    ],
                  ),
                ),
              ),
              if (hpDisplay) ...[
                LinearProgressIndicator(
                  value: health / 100,
                  minHeight: 10,
                  color: Colors.greenAccent,
                  backgroundColor: Colors.red.shade900,
                  borderRadius: BorderRadius.circular(8),
                ),
                const SizedBox(height: 8),
                Text('HP: $health / 100',
                    style: const TextStyle(color: neonBlue)),
              ],
              const SizedBox(height: 12),
              Wrap(spacing: 10, children: [
                FilledButton.icon(
                  onPressed: health == 0
                      ? null
                      : () => setState(
                          () => health = (health - 10).clamp(0, 100)),
                  icon: const Icon(Icons.gps_fixed),
                  label: const Text('PRACTICE HIT'),
                ),
                OutlinedButton(
                  onPressed: () => setState(() => health = 100),
                  child: const Text('RESET'),
                ),
              ]),
            ],
          )),
          const SizedBox(height: 18),
          panelCard(Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('AIM PRACTICE',
                  style: TextStyle(color: neonBlue,
                      fontWeight: FontWeight.bold)),
              Text('Practice sensitivity: ${sensitivity.round()}'),
              Slider(
                value: sensitivity,
                min: 1,
                max: 100,
                activeColor: neonBlue,
                onChanged: (v) => setState(() => sensitivity = v),
              ),
            ],
          )),
          const SizedBox(height: 28),
          const Center(
            child: Text('WAVE X • TRAINING EDITION • V1.0',
                style: TextStyle(color: Colors.white38, fontSize: 10,
                    letterSpacing: 1.4)),
          ),
          const SizedBox(height: 70),
        ],
      ),
    );
  }
}
